-- CreateIndex
CREATE UNIQUE INDEX "UserTermStats_userId_normalized_key" ON "UserTermStats"("userId", "normalized");

