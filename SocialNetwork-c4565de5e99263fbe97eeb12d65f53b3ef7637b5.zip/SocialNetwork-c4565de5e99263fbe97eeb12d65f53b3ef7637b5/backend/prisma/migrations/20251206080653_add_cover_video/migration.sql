-- AlterTable
ALTER TABLE "User" ADD COLUMN     "coverVideoUrl" TEXT;
